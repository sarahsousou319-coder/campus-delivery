# Campus Delivery

Bilingual Arabic/French mobile-first prototype for a university residence delivery service.

## Included
- Two sample stores: inside and outside the residence
- Sample products and categories
- Shopping cart and checkout (building, room, phone)
- Cash-on-delivery fee: 100 DZD
- Demo order list and courier status flow
- Revenue illustration: 70% courier / 30% platform
- Arabic/French language switch
- Responsive layout for phones and tablets

## Important
This is a front-end demonstration only. Orders are held temporarily in the browser and are not shared between devices. There is no real authentication, database, live courier assignment, or secure admin access yet. Do not use it for real customer orders until backend, privacy, security, and residence delivery rules are implemented.

## Publish
Enable GitHub Pages in repository Settings, select the `main` branch and `/ (root)` folder, then save. Open the Pages URL on your phone.

## Next stage
Connect Supabase for authentication and persistent data; implement store dashboards, manual courier approval, secure role permissions, and order assignment.
